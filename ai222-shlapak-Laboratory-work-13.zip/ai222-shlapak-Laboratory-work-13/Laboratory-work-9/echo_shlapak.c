#include <stdio.h>
#include <unistd.h>

int main(void){
	char * uname_args[] = {"uname","-s","-n", NULL};
	pid_t pid = fork();
	if (pid != 0){
		printf("Parent PID=%d, child PID=%d\n",getpid(),pid);
		sleep(1);
		execv("/bin/uname",uname_args);
		fprintf(stderr,"Command error\n");
		return 1;
	}
	else
		printf("Child PID=%d, Parent PID=%d\n",getpid(),getppid());
	return 0;
}
