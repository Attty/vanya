## Основи програмного керування процесями в Unix-подібних ОС

2.1.1
![image](https://user-images.githubusercontent.com/127392399/236138862-592635a1-a3dc-4620-b9ae-dbfa05029189.png)

2.1.2. При паралельному Group PID відрізняються, а при конвеєрному ні. А PID відрізняється і там, і там.
![image](https://user-images.githubusercontent.com/127392399/236140082-de04fda4-9fcc-4763-905d-0b6c7c1b4c03.png)
 
 2.2.1
 ![image](https://user-images.githubusercontent.com/127392399/236147186-5a060025-d5fd-4e97-ad2a-197fb5be561a.png)
