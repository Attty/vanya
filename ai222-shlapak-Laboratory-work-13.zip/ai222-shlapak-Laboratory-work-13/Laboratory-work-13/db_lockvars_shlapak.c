#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>

int turn = 0;
struct graphicscard {
    int h_id;
    char model[20];
    int size_gb;
};
struct graphicscard graphicscard [2] = { { 1, "NVIDIA RTX 4090", 24 } };
void main(void) {
   pthread_t T1_thread, T2_thread;
   void *T1(), *T2();
   pthread_create(&T1_thread, NULL, T1, NULL);
   pthread_create(&T2_thread, NULL, T2, NULL);
   pthread_join(T1_thread, NULL);
   pthread_join(T2_thread, NULL);
}
void *T1() {
    for (int i = 1; i <= 3; i++) {
        while (turn != 0);
        sleep(2);
        turn = 1;
        printf("T1: Critical Region\n");
        printf("T1: Read[size_gb] = %d\n", graphicscard[0].size_gb);
        sleep(1);
        graphicscard[0].size_gb = 24;
        printf("T1: Write[size_gb] = %d\n", graphicscard[0].size_gb);
        sleep(1);
        turn = 0;
        printf("T1: Noncritical Region\n");
        sleep(1);
    }
}
void *T2() {
    sleep(1);
    for (int i = 1; i <= 3; i++) {
        while (turn !=0);
        sleep(2);
        turn = 1;
        printf("T2: Critical Region\n");
        printf("T2: Read[size_gb] = %d\n", graphicscard[0].size_gb);
        sleep(1);
        graphicscard[0].size_gb = 23;
        printf("T2: Write[size_gb] = %d\n", graphicscard[0].size_gb);
        sleep(1);
        turn = 0;
        printf("T2: Noncritical Region\n");
        sleep(1);
    }
}


