#include "graphicscard.h"

PGconn* connect_graphicscard (void) {
        PGconn *conn;
        char db_name [] = "shlapak";
        char user_name[] = "shlapak";

        conn = PQsetdbLogin(NULL,NULL,NULL,NULL,db_name,user_name,NULL);
        if (PQstatus(conn) == CONNECTION_OK ) {
                printf("Conection to database %s is successfull!\n",db_name);
		return conn;
	}
        else {
            fprintf(stderr, "Connect to database %s failed: %s", db_name,PQerrorMessage(conn));
            return NULL;
       }
}



