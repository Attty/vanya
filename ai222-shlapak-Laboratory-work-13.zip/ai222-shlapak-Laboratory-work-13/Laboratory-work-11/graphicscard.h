#include <stdio.h>
#include <stdlib.h>
#include "libpq-fe.h"

PGconn* connect_graphicscard (void);
ExecStatusType remove_graphicscard(PGconn* conn);
ExecStatusType add_graphicscard(PGconn* conn);
ExecStatusType get_graphicscard(PGconn* conn);
