## «Етапи компіляції С-програм та автоматизація побудови С-програм»

### 2.1 Побудова програми з’єднання з СКБД PostgreSQL на основі монолітної С-програми

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/6ebd0f67-fecb-4aed-b4f3-c64ffb15ef82)
### 2.1.1 Створити C-програму з назвою «db_connect.c», яка:

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/498f1674-c16e-431f-9862-8770a22fd488)

### 2.1.2 Скомпілювати С-програму, враховуючи каталоги з header-файлами та бібліотеками СКБД PostgreSQL.

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/825009d0-16fe-4a4f-9e99-1f09737feb5b)

### 2.1.3 Створити C-програму з назвою «db_connect_param.c», яка повторює всі дії C-програми з назвою «db_connect.c», але назву бази даних та ім’я користувача програма повинна брати як параметри командного рядку.

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/c742ac33-7fcd-4c26-b4a3-94225b866c90)

### 2.1.4 Скомпілювати С-програму, враховуючи каталоги з header-файлами та бібліотеками СКБД PostgreSQL.

### 2.2 Побудова програми з’єднання з СКБД PostgreSQL за модульним принципом програмування

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/7e9c322d-84ce-4d01-8e85-25ef24bbdd61)
![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/9f40b6f4-1ddb-420c-9690-31df35a6a554)
![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/0b9cf1b0-1847-4e97-91ce-c222b09f28ae)

### 2.2.1 Змінити код С-програми, враховуючи модульний принцип програмування:  оформити програмний код з’єднання із СКБД PostgreSQL у вигляді функції зназвою «connect_назва таблиці», де «назва таблиці» - назва реляційної таблиці з попередньої лабораторної работи;

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/835ef8b8-251d-4737-8d73-ae1a0b6a9e99)

### 2.3.2 Побудувати executable-файл через кроки

## 2.3 Побудова програми з’єднання з СКБД PostgreSQL через команду make

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/541029f5-ef84-4cb4-bdfa-da5ed9028b8f)

### 2.3.1 Створити Makefile, який містить наступний опис мети:

![image](https://github.com/oleksandrblazhko/ai222-shlapak/assets/127392399/ef24b7ba-5d3c-4e0a-a8d7-7dca5094615d)

### 2.3.2 Скомпілювати С-файли програмних модулів командою make.
