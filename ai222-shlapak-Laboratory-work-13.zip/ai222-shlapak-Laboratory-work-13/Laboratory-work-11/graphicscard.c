#include "graphicscard.h"

int main (void) {
	PGconn *conn;
	conn = connect_graphicscard();
	if(conn == NULL)
		return EXIT_FAILURE;
	PQfinish(conn);
	return EXIT_SUCCESS;
}

