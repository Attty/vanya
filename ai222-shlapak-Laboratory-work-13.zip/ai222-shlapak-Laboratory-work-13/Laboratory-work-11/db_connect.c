#include <stdio.h>
#include <stdlib.h>
#include "libpq-fe.h"

int main (void){
	PGconn *conn;
	char db_name [] = "shlapak";
	char user_name[] = "shlapak";

	conn = PQsetdbLogin(NULL,NULL,NULL,NULL,db_name,user_name,NULL);
	if (PQstatus(conn) == CONNECTION_OK )  
		printf("Conection to database %s is successfull!\n",db_name);
	else {
	    fprintf(stderr, "Connect to database %s failed: %s", db_name,PQerrorMessage(conn));
	    return EXIT_FAILURE;
       }
       PQfinish(conn);
       return EXIT_SUCCESS;
}

