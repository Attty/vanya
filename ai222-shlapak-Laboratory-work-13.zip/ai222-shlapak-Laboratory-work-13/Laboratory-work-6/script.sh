#!/bin/bash
awk 'BEGIN{FS=":"} NR <= 127 && $1~/^s/ {print $1}' /etc/passwd
