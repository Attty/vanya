#!/bin/bash

param_name=$1
param_name2=$2
param_value=$(cat /proc/meminfo| grep Active | awk '{print $2}')

if [ "$param_name" == "Active" ]; then
	echo "Значення параметру Active: $param_value"
else
	echo "Параметр не знайдено"
fi

if [ "$param_name2" = "info" ]; then
	echo "Опис призначення параметру Active: Загальний розмір розділу Active"
fi
