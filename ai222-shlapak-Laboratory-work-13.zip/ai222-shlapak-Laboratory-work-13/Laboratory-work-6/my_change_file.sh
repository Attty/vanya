#!/bin/bash

read -p "Ведіть назву об'єкту, яку необхідно змінити: " object_name

if [ ! -e $object_name ]; then
	echo "Помилка: Об'єкт не знайдено."
	exit 1
fi

name_length=${#object_name}
if [ $name_length -gt 16 ]; then
	echo "Помилка: Назва об'єкту занадто довга"
	exit 1
fi
if [[ $object_name =~ [0-9]{13,} ]]; then
	echo "Помилка: Назва об'єкту містить 13 цифр підряд."
	exit 1
fi

mv $object_name new.txt

echo "Назву об'єкту успішно змінено."
exit 0
