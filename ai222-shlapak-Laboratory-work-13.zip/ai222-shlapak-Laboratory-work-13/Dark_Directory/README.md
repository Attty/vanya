https://github.com/Attty/WebAR-Huhges/tree/BookLet_with_pattern_marker
